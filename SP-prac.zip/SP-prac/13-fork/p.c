#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include <stdio.h>
#include <sys/wait.h>
#include <stdlib.h>



int main()
{
    pid_t child_pid;
    int status;
    int a=0;
    int b=0;
   
    child_pid = fork(); 

    if (child_pid >= 0) 
{
        if (child_pid == 0) 
        {
            printf("child process!\n");

           
            a++;
            b++;

            printf("child PID =  %d, parent pid = %d\n", getpid(), getppid());
            printf("\n value of a in child = %d, value of b in child = %d\n",a,b);

           
            char command2[1024];
            char* const parmList[] = {"ps",  NULL};
            execvp("/bin/ps", parmList);

          
         }
         else 
         {
             printf("parent process!\n");
             printf("parent PID =  %d, child pid = %d\n", getpid(), child_pid);
             wait(&status); 
             printf("Child exit code: %d\n", WEXITSTATUS(status));  
            
             printf("\n value of a in parent = %d, value of b in parent = %d\n",a,b);

             printf("Parent says bye!\n");
             exit(0);  
         }
    }
    else 
    {
        perror("fork");
        exit(0);
    }
}
