import java.util.*;
public class Process
{
Scanner sc=new Scanner(System.in);
int n, page[], f, frames[], faults, count;
double rate;

public Process()
{
System.out.println("Enter number of pages");
n=sc.nextInt();
page=new int[n];
System.out.println("Enter number of page frames");
f=sc.nextInt();
frames=new int[f];
count=1;
}

void reset()
{
int j;
for(j=0;j<f;j++)
frames[j]=0;
faults=0;
count=1;
}



void read()
{
int i;
System.out.println("Enter the pages");
for(i=0;i<n;i++)
{
System.out.println("Enter page number "+(i+1));
page[i]=sc.nextInt();
}
for(i=0;i<f;i++)
frames[i]=-1;
}


void lru()
{
int i,j,duration[],max;
reset();
duration=new int[f];
boolean found=false;
for(i=0;i<n;i++)
{
    for(j=0;j<f;j++)
    duration[j]++;
			    for(j=0;j<f;j++)
			    {
			     if(page[i]==frames[j])
			      {
			         found=true;
			         duration[j]=0;
			      }
			    }
        if(found==false)
         {
           max=0;
	           for(j=0;j<f;j++)
	             {
	               if(duration[j]>duration[max])
	               max=j;
	             }
	           frames[max]=page[i];
	           duration[max]=0;
	           faults++;
        }

display();
found=false;

}
System.out.println("Number of page faults = "+faults);

}

void opt()
{
int i,j=0,k,duration[],max,flag[];
reset();
duration=new int[f];
flag=new int[f];
boolean found=false;

for(i=0;i<n;i++)
{
			for(j=0;j<f;j++)
			{
					flag[j]=0;
					duration[j]=n;
			}

for(k=i+1;k<n;k++)
{
for(j=0;j<f;j++)
if(page[k]==frames[j]&&flag[j]==0)
{
duration[j]=k;
flag[j]=1;
}
}

for(j=0;j<f;j++)
if(page[i]==frames[j])
found=true;
if(found==false)
{
max=0;
for(j=0;j<f;j++)
{
if(duration[j]>duration[max])
max=j;
if(frames[j]<0)
{
max=j;
break;
}
}
frames[max]=page[i];
faults++;
}

display();
found=false;

}
System.out.println("Number of page faults = "+faults);

}

void display()
{
int i;
System.out.print("Page frame "+count+" :");
for(i=0;i<f;i++)
{
if(frames[i]==-1)
System.out.print(" -");
else
System.out.print(" "+frames[i]);
}
System.out.print("\n");
count++;
}
public static void main(String[] args) {
int option;
int choice;
Process p=new Process();
p.read();
Scanner scr=new Scanner(System.in);
do
{
System.out.println("Menu");
System.out.println("1. LRU");
System.out.println("2. OPT");
System.out.println("Enter option");
option=scr.nextInt();
switch(option)
{
case 1: p.lru();
break;
case 2: p.opt();
break;
default: System.out.println("Invalid input");
}
System.out.println("Press 1 to continue");
choice=scr.nextInt();
}
while(choice==1);
}
}

/*OUTPUT

 * Enter number of pages
12
Enter number of page frames
3
Enter the pages
Enter page number 1
1
Enter page number 2
2
Enter page number 3
3
Enter page number 4
4
Enter page number 5
1
Enter page number 6
2
Enter page number 7
5
Enter page number 8
1
Enter page number 9
2
Enter page number 10
3
Enter page number 11
4
Enter page number 12
5
Menu
1. LRU
2. OPT
Enter option
1
Page frame 1 : 1 0 0
Page frame 2 : 1 2 0
Page frame 3 : 1 2 3
Page frame 4 : 4 2 3
Page frame 5 : 4 1 3
Page frame 6 : 4 1 2
Page frame 7 : 5 1 2
Page frame 8 : 5 1 2
Page frame 9 : 5 1 2
Page frame 10 : 3 1 2
Page frame 11 : 3 4 2
Page frame 12 : 3 4 5
Number of page faults = 10
Press 1 to continue
1
Menu
1. LRU
2. OPT
Enter option
2
Page frame 1 : 1 0 0
Page frame 2 : 1 2 0
Page frame 3 : 1 2 3
Page frame 4 : 1 2 4
Page frame 5 : 1 2 4
Page frame 6 : 1 2 4
Page frame 7 : 1 2 5
Page frame 8 : 1 2 5
Page frame 9 : 1 2 5
Page frame 10 : 3 2 5
Page frame 11 : 4 2 5
Page frame 12 : 4 2 5
Number of page faults = 7
Press 1 to continue
3
*/
