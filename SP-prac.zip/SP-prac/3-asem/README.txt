Commands to execute the Two Pass Assembler.

1. javac PassOne.java
2. java PassOne TestCode.txt
3. javac PassTwo.java
4. java PassTwo

NOTE:
	Can execute for any file that contains the Mnemonic Codes of OpTab.txt
	Replace the name of your code with TestCode.txt before execution.
	For proper execution ensure the perfect indentation of the Assembly Code.
	Necessary assumptions are already made add yours if required.
	
Expected Output:
After 1,2 commands:
	3 files will be created with data in desired form:
		1. Intermediate Code file
		2. Symbol table file
		3. Literal table file.
		
After 3, 4:
	A file named ByteCode will be created containing the 
	byte code of the Assembly Program taken as i/p.

