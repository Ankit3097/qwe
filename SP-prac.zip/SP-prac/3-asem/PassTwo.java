import java.io.*;

class PassTwo
{
	File f;
	BufferedReader inter;
	PrintWriter byteCode;
	
	PassTwo() throws Exception
	{	
		f = new File("Intermediate.txt");
		inter = new BufferedReader(new FileReader(f));
		
		f = new File("ByteCode.txt");
		byteCode = new PrintWriter(f);
	}//constructor
	
	void createByteCode() throws Exception
	{
		String instruction;
		String optabEntry;
		int mnemonic, opcode;
		
		while((instruction = inter.readLine()) != null)
		{
			String val[] = instruction.split(" ");
			
			mnemonic = getValue("OpTab.txt", val[1], 0, 1);
			if(mnemonic != -1)
			{
				opcode = getValue("SymbolTable.txt", val[2], 0, 1);
				optabEntry = val[0] + ": "+ mnemonic + opcode;
				byteCode.println(optabEntry); 
			}//if
			
			mnemonic = getValue("OpTab.txt", val[2], 0, 1);
			if(mnemonic != -1)
			{
				if(val.length == 4)
				{
					opcode = getValue("LiteralTable.txt", val[0], 1, 0);
					optabEntry = val[0] + ":" + " 0000" + opcode;
					byteCode.println(optabEntry); 
				}//if
			}//if
		}//while
		
		byteCode.close();
	}//createByteCode
	
	int getValue(String fname, String s, int x, int y) throws Exception
	{
		String opcode;
		String mnemonic[];
		f = new File(fname);
		BufferedReader optab = new BufferedReader(new FileReader(f));
		
		while((opcode = optab.readLine())!= null)
		{
			mnemonic = opcode.split(" ");
			if(mnemonic[x].equals(s))
				return Integer.parseInt(mnemonic[y]);
		}//while
		optab.close();
		return -1;
	}//getValue
	
	public static void main(String ... args)
	{
		try
		{
			PassTwo pt = new PassTwo();
			pt.createByteCode();
		}//try
		
		catch(Exception e)
		{
			e.printStackTrace();
		}//catch
	
	}//main
	
}//PassTwo
