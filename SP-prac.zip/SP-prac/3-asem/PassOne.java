import java.io.*;

class PassOne
{
	File f;
	BufferedReader optab, codefile;
	PrintWriter inter, symTab, litTab;
	int locctr;
	
	PassOne(String fname) throws Exception
	{
		f = new File(fname);
		codefile = new BufferedReader(new FileReader(f));
		
		f = new File("Intermediate.txt");
		inter = new PrintWriter(f);
		
		f = new File("SymbolTable.txt");
		symTab = new PrintWriter(f);
		
		f = new File("LiteralTable.txt");
		litTab = new PrintWriter(f);
	}//PassOne
	
	void read() throws Exception
	{
		String instruction;
		char type = ' ';
		boolean flag;
		
		while((instruction = codefile.readLine()) != null)
		{
			String val[] = instruction.toUpperCase().split(" ");
			String optabEntry;
			int mnemonicLength;
			
			if(instruction.equals(""))
				continue;
			
			if(val[0].equals("START"))
				locctr = Integer.parseInt(val[1]);
				
			mnemonicLength = findLenOfMnemonic(val[0]);
			
			if(mnemonicLength != -1)
			{
				optabEntry = locctr + " " + instruction; 
				inter.println(optabEntry);
				locctr += mnemonicLength;
			}//if	
					
			switch(val[1])
			{
				case "BYTE":
					type = 'B';
					flag = true;
					break;
					
				case "WORD":
					type = 'W';
					flag = true;
					break;
					
				case "DOUBLE":
					type = 'D';
					flag = true;
					break;
					
				case "QUADWORD":
					type = 'Q';
					flag = true;
					break;
				
				default:
					flag = false;
			}//switch
			
			if(flag)
			{
				litTab.println(val[2] + " " + locctr);
				symTab.println(val[0] + " " + locctr);
				optabEntry = locctr + " " + val[0] + " " + val[1] + " " + val[2];
				inter.println(optabEntry);
				
				if(type == 'B')
					locctr += 1;
					
				if(type == 'W')
					locctr += 2;
					
				if(type == 'D')
					locctr += 4;
					
				if(type == 'Q')
					locctr += 8;
					
				flag = false;
			}//if
			
			switch(val[1])
			{
				case "RESB":
					type = 'b';
					flag = true;
					break;
					
				case "RESW":
					type = 'w';
					flag = true;
					break;
					
				case "RESD":
					type = 'd';
					flag = true;
					break;
					
				case "RESQ":
					type = 'q';
					flag = true;
					break;
				
				default:
					flag = false;
			}//switch
			
			if(flag)
			{
				symTab.println(val[0] + " " + locctr);
				optabEntry = locctr + " " + val[0] + " " + val[1];
				inter.println(optabEntry);
				
				if(type == 'b')
					locctr += Integer.parseInt(val[2]);	
				
				if(type == 'w')
				locctr += 2 * Integer.parseInt(val[2]);
				
				if(type == 'd')
				locctr += 4 * Integer.parseInt(val[2]);
				
				if(type == 'q')
				locctr += 8 * Integer.parseInt(val[2]);
				
				flag = false;
			}//if	
		}//while
		symTab.close();
		litTab.close();
		inter.close();
	}//read

	int findLenOfMnemonic(String s) throws Exception
	{
		String opcode;
		String mnemonic[];
		f = new File("OpTab.txt");
		optab = new BufferedReader(new FileReader(f));
		
		while((opcode = optab.readLine())!= null)
		{
			mnemonic = opcode.split(" ");
			if(mnemonic[0].equals(s))
				return Integer.parseInt(mnemonic[3]);
		}//while
		optab.close();
		return -1;
	}//findLenOfMnemonic
	
	public static void main(String ... args)
	{
		try
		{
			PassOne op = new PassOne(args[0]);
			op.read();
		}//try
		catch(Exception e)
		{
			System.out.println(e);
		}//catch
	}//main
}//PassOne
